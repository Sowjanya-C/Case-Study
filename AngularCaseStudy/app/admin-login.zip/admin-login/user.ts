export class LoginInterface {
    userID: number=0;
    userName!: string;
    password!: string;
}